package com.overflaremc.spiretokens.commands;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.utils.FormatUtil;
import com.overflaremc.spiretokens.utils.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RankCommand implements CommandExecutor {
    private final SpireTokens plugin;
    public RankCommand(SpireTokens plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Player only!"); return true; }
        int tier = plugin.getDataManager().getRank(player.getUniqueId());
        MessageUtil.send(player, "rank-current", "{rank}", plugin.getRankManager().getRankName(tier));
        if (tier < 5) {
            int next = tier + 1;
            MessageUtil.send(player, "rank-next", "{next}", plugin.getRankManager().getRankName(next), "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{cost}", FormatUtil.formatNum(plugin.getRankManager().getRankCost(next)));
        } else {
            MessageUtil.send(player, "rank-max");
        }
        return true;
    }
}
