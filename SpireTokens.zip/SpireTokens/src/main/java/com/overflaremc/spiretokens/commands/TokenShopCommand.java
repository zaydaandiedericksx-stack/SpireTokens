package com.overflaremc.spiretokens.commands;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.data.DataManager;
import com.overflaremc.spiretokens.utils.FormatUtil;
import com.overflaremc.spiretokens.utils.MessageUtil;
import org.bukkit.Material;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class TokenShopCommand implements CommandExecutor, TabExecutor {
    private final SpireTokens plugin;
    public TokenShopCommand(SpireTokens plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Player only!"); return true; }
        if (args.length == 0) { plugin.getShopManager().openShop(player); return true; }
        if (!player.hasPermission("spiretokens.admin")) { MessageUtil.send(player, "no-permission"); return true; }
        switch (args[0].toLowerCase()) {
            case "add" -> {
                if (args.length < 3) { player.sendMessage(MessageUtil.toComponent("&cUsage: /tokenshop add <material> <slot> [price]")); return true; }
                Material mat = Material.matchMaterial(args[1]);
                if (mat == null) { player.sendMessage(MessageUtil.toComponent("&cInvalid material!")); return true; }
                int slot = FormatUtil.parseInt(args[2]);
                if (slot < 0 || slot > 53) { MessageUtil.send(player, "shop-invalid-slot"); return true; }
                double price = args.length >= 4 ? FormatUtil.parseDouble(args[3]) : plugin.getConfigManager().getDefaultShopPrice();
                if (price < 0) price = plugin.getConfigManager().getDefaultShopPrice();
                plugin.getShopManager().addItem(slot, new ItemStack(mat), price);
                MessageUtil.send(player, "shop-item-added", "{item}", mat.name(), "{slot}", String.valueOf(slot), "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{price}", FormatUtil.formatNum(price));
            }
            case "addhand" -> {
                ItemStack hand = player.getInventory().getItemInMainHand();
                if (hand.getType().isAir()) { player.sendMessage(MessageUtil.toComponent("&cHold an item in your hand first!")); return true; }
                int slot = -1;
                if (args.length >= 2) slot = FormatUtil.parseInt(args[1]);
                else { for (int i = 0; i < 54; i++) { if (plugin.getDataManager().getShopItem(i) == null) { slot = i; break; } } }
                if (slot < 0 || slot > 53) { player.sendMessage(MessageUtil.toComponent("&cNo empty slots or invalid slot!")); return true; }
                double price = args.length >= 3 ? FormatUtil.parseDouble(args[2]) : plugin.getConfigManager().getDefaultShopPrice();
                if (price < 0) price = plugin.getConfigManager().getDefaultShopPrice();
                plugin.getShopManager().addItem(slot, hand.clone(), price);
                MessageUtil.send(player, "shop-item-added", "{item}", hand.getType().name(), "{slot}", String.valueOf(slot), "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{price}", FormatUtil.formatNum(price));
            }
            case "remove" -> {
                if (args.length < 2) { player.sendMessage(MessageUtil.toComponent("&cUsage: /tokenshop remove <slot>")); return true; }
                int slot = FormatUtil.parseInt(args[1]);
                plugin.getShopManager().removeItem(slot);
                MessageUtil.send(player, "shop-item-removed", "{slot}", String.valueOf(slot));
            }
            case "price" -> {
                if (args.length < 3) { player.sendMessage(MessageUtil.toComponent("&cUsage: /tokenshop price <slot> <price>")); return true; }
                int slot = FormatUtil.parseInt(args[1]);
                if (plugin.getDataManager().getShopItem(slot) == null) { player.sendMessage(MessageUtil.toComponent("&cNo item in slot " + slot + "! Add one first.")); return true; }
                double price = FormatUtil.parseDouble(args[2]);
                plugin.getShopManager().setPrice(slot, price);
                MessageUtil.send(player, "shop-price-set", "{slot}", String.valueOf(slot), "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{price}", FormatUtil.formatNum(price));
            }
            case "list" -> {
                player.sendMessage(MessageUtil.toComponent("&6&lToken Shop Items:"));
                boolean found = false;
                for (var entry : plugin.getDataManager().getShopItems().entrySet()) {
                    DataManager.ShopItemData data = entry.getValue();
                    player.sendMessage(MessageUtil.toComponent("&eSlot " + entry.getKey() + ": &f" + data.item().getType().name() + " &7- " + plugin.getConfigManager().getTokenSymbol() + "&6" + FormatUtil.formatNum(data.price())));
                    found = true;
                }
                if (!found) player.sendMessage(MessageUtil.toComponent("&7No items in shop."));
            }
            case "rows" -> {
                if (args.length < 2) { player.sendMessage(MessageUtil.toComponent("&cUsage: /tokenshop rows <1-6>")); return true; }
                int rows = FormatUtil.parseInt(args[1]);
                plugin.getShopManager().setRows(rows);
                int slots = plugin.getShopManager().getRows() * 9;
                player.sendMessage(MessageUtil.toComponent("&aShop GUI set to &e" + plugin.getShopManager().getRows() + " rows &a(&e" + slots + " slots&a)."));
            }
            case "fill" -> {
                if (args.length < 2) { player.sendMessage(MessageUtil.toComponent("&cUsage: /tokenshop fill <material>")); return true; }
                Material mat = Material.matchMaterial(args[1]);
                if (mat == null) { player.sendMessage(MessageUtil.toComponent("&cInvalid material!")); return true; }
                plugin.getShopManager().fillEmptySlots(mat);
            }
            default -> player.sendMessage(MessageUtil.toComponent("&cUnknown subcommand. Use: add, addhand, remove, price, list, rows, fill"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> list = new ArrayList<>();
        if (args.length == 1) list.addAll(List.of("add", "addhand", "remove", "price", "list", "rows", "fill"));
        else if (args.length == 2 && (args[0].equalsIgnoreCase("add") || args[0].equalsIgnoreCase("fill"))) {
            for (Material m : Material.values()) if (m.isItem()) list.add(m.name().toLowerCase());
        }
        return list;
    }
}
