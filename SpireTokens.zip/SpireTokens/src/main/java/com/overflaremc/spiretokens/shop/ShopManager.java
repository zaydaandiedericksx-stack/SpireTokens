package com.overflaremc.spiretokens.shop;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.data.DataManager;
import com.overflaremc.spiretokens.gui.QuantityGUI;
import com.overflaremc.spiretokens.gui.ShopGUI;
import com.overflaremc.spiretokens.utils.FormatUtil;
import com.overflaremc.spiretokens.utils.MessageUtil;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.Map;

public class ShopManager {
    private final SpireTokens plugin;
    private int rows = 3;

    public ShopManager(SpireTokens plugin) {
        this.plugin = plugin;
        this.rows = plugin.getConfigManager().getDefaultShopRows();
    }

    public void setRows(int rows) { this.rows = Math.max(1, Math.min(6, rows)); }
    public int getRows() { return rows; }
    public void openShop(Player player) { new ShopGUI(plugin, player).open(); }
    public void openQuantity(Player player, int slot) {
        DataManager.ShopItemData data = plugin.getDataManager().getShopItem(slot);
        if (data == null) { player.sendMessage(MessageUtil.toComponent("&cItem not found!")); return; }
        new QuantityGUI(plugin, player, slot, data.item(), data.price()).open();
    }
    public void addItem(int slot, ItemStack item, double price) { plugin.getDataManager().setShopItem(slot, item, price); }
    public void removeItem(int slot) { plugin.getDataManager().removeShopItem(slot); }
    public void setPrice(int slot, double price) { plugin.getDataManager().setShopPrice(slot, price); }
    public Map<Integer, DataManager.ShopItemData> getItems() { return plugin.getDataManager().getShopItems(); }
    public void fillEmptySlots(Material material) {
        int totalSlots = rows * 9;
        Map<Integer, DataManager.ShopItemData> items = getItems();
        int filled = 0;
        for (int i = 0; i < totalSlots; i++) {
            if (!items.containsKey(i)) {
                ItemStack filler = new ItemStack(material);
                ItemMeta meta = filler.getItemMeta(); meta.displayName(MessageUtil.toComponent(" ")); filler.setItemMeta(meta);
                addItem(i, filler, 999_999_999);
                filled++;
            }
        }
        MessageUtil.sendRaw(null, "&aFilled &e" + filled + " &aempty slots with &e" + material.name() + "&a.");
    }
    public void buyItem(Player player, int slot, int quantity) {
        DataManager.ShopItemData data = plugin.getDataManager().getShopItem(slot);
        if (data == null) { player.sendMessage(MessageUtil.toComponent("&cError: Item not found!")); return; }
        if (quantity < 1) { player.sendMessage(MessageUtil.toComponent("&cQuantity must be at least 1!")); return; }
        double total = data.price() * quantity;
        double balance = plugin.getDataManager().getTokens(player.getUniqueId());
        if (balance < total) {
            player.sendMessage(MessageUtil.toComponent(plugin.getConfigManager().getMessage("shop-no-money", "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{amount}", FormatUtil.formatNum(total))));
            return;
        }
        plugin.getDataManager().removeTokens(player.getUniqueId(), total);
        for (int i = 0; i < quantity; i++) player.getInventory().addItem(data.item().clone());
        player.sendMessage(MessageUtil.toComponent(plugin.getConfigManager().getMessage("shop-buy", "{item}", data.item().getType().name(), "{qty}", String.valueOf(quantity), "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{total}", FormatUtil.formatNum(total))));
    }
}
