package com.overflaremc.spiretokens.afk;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.data.DataManager;
import com.overflaremc.spiretokens.utils.FormatUtil;
import com.overflaremc.spiretokens.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.scheduler.BukkitRunnable;
import org.bukkit.scheduler.BukkitTask;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class AFKManager implements Listener {
    private final SpireTokens plugin;
    private final Map<UUID, Integer> countdowns = new HashMap<>();
    private final Map<UUID, Location> wandPos1 = new HashMap<>();
    private final Map<UUID, Location> wandPos2 = new HashMap<>();
    private BukkitTask afkTask;

    public AFKManager(SpireTokens plugin) { this.plugin = plugin; }

    public void startAFKTask() {
        afkTask = new BukkitRunnable() {
            @Override
            public void run() {
                for (Player player : Bukkit.getOnlinePlayers()) {
                    if (isInAFKArea(player)) processAFK(player);
                    else countdowns.remove(player.getUniqueId());
                }
            }
        }.runTaskTimer(plugin, 20L, 20L);
    }

    public void stopAFKTask() { if (afkTask != null) afkTask.cancel(); }

    private void processAFK(Player player) {
        UUID uuid = player.getUniqueId();
        int interval = plugin.getConfigManager().getAFKInterval();
        int countdown = countdowns.getOrDefault(uuid, interval);
        countdown--;
        if (countdown <= 0) {
            double mult = getMultiplier(player);
            double amount = plugin.getConfigManager().getAFKReward() * mult;
            plugin.getDataManager().addTokens(uuid, amount);
            countdown = interval;
            if (mult > 1) MessageUtil.sendActionBar(player, plugin.getConfigManager().getMessage("afk-reward-mult", "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{amount}", FormatUtil.formatNum(amount), "{mult}", String.valueOf(mult)));
            else MessageUtil.sendActionBar(player, plugin.getConfigManager().getMessage("afk-reward", "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{amount}", FormatUtil.formatNum(amount)));
        } else {
            MessageUtil.sendActionBar(player, plugin.getConfigManager().getMessage("afk-actionbar", "{countdown}", String.valueOf(countdown), "{mult}", String.valueOf(getMultiplier(player))));
        }
        countdowns.put(uuid, countdown);
    }

    public boolean isInAFKArea(Player player) {
        Location loc = player.getLocation();
        double x = loc.getX(), y = loc.getY(), z = loc.getZ();
        for (DataManager.AFKAreaData area : plugin.getDataManager().getAFKAreas().values()) {
            Location p1 = area.pos1(), p2 = area.pos2();
            if (p1 == null || p2 == null) continue;
            double minX = Math.min(p1.getX(), p2.getX()), maxX = Math.max(p1.getX(), p2.getX());
            double minY = Math.min(p1.getY(), p2.getY()), maxY = Math.max(p1.getY(), p2.getY());
            double minZ = Math.min(p1.getZ(), p2.getZ()), maxZ = Math.max(p1.getZ(), p2.getZ());
            if (x >= minX && x <= maxX && y >= minY && y <= maxY && z >= minZ && z <= maxZ) return true;
        }
        return false;
    }

    public double getMultiplier(Player player) {
        double mult = 1.0;
        for (String perm : new String[]{"spiretokens.mult.5", "spiretokens.mult.4", "spiretokens.mult.3", "spiretokens.mult.2", "spiretokens.mult.1"}) {
            if (player.hasPermission(perm)) mult = Math.max(mult, plugin.getConfigManager().getMultiplier(perm));
        }
        return mult;
    }

    public void giveWand(Player player) {
        ItemStack wand = new ItemStack(Material.STICK);
        ItemMeta meta = wand.getItemMeta();
        meta.displayName(MessageUtil.toComponent("&cAFK Wand"));
        meta.lore(java.util.Arrays.asList(MessageUtil.toComponent("&7Left Click: Set Pos 1"), MessageUtil.toComponent("&7Right Click: Set Pos 2"), MessageUtil.toComponent(""), MessageUtil.toComponent("&eThen use /afk set")));
        wand.setItemMeta(meta);
        player.getInventory().addItem(wand);
        MessageUtil.send(player, "afk-wand-given");
    }

    public void setPos1(Player player, Location loc) {
        wandPos1.put(player.getUniqueId(), loc);
        MessageUtil.send(player, "afk-pos1", "{x}", String.valueOf(loc.getBlockX()), "{y}", String.valueOf(loc.getBlockY()), "{z}", String.valueOf(loc.getBlockZ()));
    }

    public void setPos2(Player player, Location loc) {
        wandPos2.put(player.getUniqueId(), loc);
        MessageUtil.send(player, "afk-pos2", "{x}", String.valueOf(loc.getBlockX()), "{y}", String.valueOf(loc.getBlockY()), "{z}", String.valueOf(loc.getBlockZ()));
    }

    public boolean canCreateArea(Player player) {
        UUID uuid = player.getUniqueId();
        if (!wandPos1.containsKey(uuid)) { player.sendMessage(MessageUtil.toComponent("&cSet Pos 1 first! Left click with the AFK Wand.")); return false; }
        if (!wandPos2.containsKey(uuid)) { player.sendMessage(MessageUtil.toComponent("&cSet Pos 2 first! Right click with the AFK Wand.")); return false; }
        return true;
    }

    public int createArea(Player player) {
        UUID uuid = player.getUniqueId();
        int id = plugin.getDataManager().addAFKArea(wandPos1.get(uuid), wandPos2.get(uuid));
        wandPos1.remove(uuid); wandPos2.remove(uuid);
        return id;
    }

    public void deleteArea(int id) { plugin.getDataManager().removeAFKArea(id); }

    @EventHandler
    public void onWandUse(PlayerInteractEvent event) {
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType() != Material.STICK || !item.hasItemMeta() || !item.getItemMeta().hasDisplayName()) return;
        String name = net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer.plainSerial().serialize(item.getItemMeta().displayName());
        if (!name.equals("AFK Wand")) return;
        if (event.getAction() == Action.LEFT_CLICK_BLOCK) { setPos1(player, event.getClickedBlock().getLocation()); event.setCancelled(true); }
        else if (event.getAction() == Action.RIGHT_CLICK_BLOCK) { setPos2(player, event.getClickedBlock().getLocation()); event.setCancelled(true); }
    }
}
