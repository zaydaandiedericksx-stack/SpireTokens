package com.overflaremc.spiretokens.commands;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.utils.FormatUtil;
import com.overflaremc.spiretokens.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class TokenAdminCommand implements CommandExecutor, TabExecutor {
    private final SpireTokens plugin;
    public TokenAdminCommand(SpireTokens plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 3) {
            sender.sendMessage(MessageUtil.toComponent("&cUsage: /stoken <set|add|give|take|reset> <player> <amount>"));
            return true;
        }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[1]);
        if (target == null || (!target.hasPlayedBefore() && !target.isOnline())) {
            MessageUtil.send(sender, "player-not-found"); return true;
        }
        double amount = FormatUtil.parseDouble(args[2]);
        if (amount < 0 && !args[0].equalsIgnoreCase("reset")) { MessageUtil.send(sender, "invalid-number"); return true; }
        switch (args[0].toLowerCase()) {
            case "set" -> {
                plugin.getDataManager().setTokens(target.getUniqueId(), amount);
                MessageUtil.send(sender, "token-set", "{player}", target.getName(), "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{amount}", FormatUtil.formatNum(amount));
                if (target.isOnline() && target.getPlayer() != null) MessageUtil.send(target.getPlayer(), "token-set-target", "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{amount}", FormatUtil.formatNum(amount));
            }
            case "add", "give" -> {
                plugin.getDataManager().addTokens(target.getUniqueId(), amount);
                MessageUtil.send(sender, "token-add", "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{amount}", FormatUtil.formatNum(amount), "{name}", plugin.getConfigManager().getTokenName(), "{player}", target.getName());
                if (target.isOnline() && target.getPlayer() != null) MessageUtil.send(target.getPlayer(), "token-add-target", "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{amount}", FormatUtil.formatNum(amount), "{name}", plugin.getConfigManager().getTokenName());
            }
            case "take" -> {
                plugin.getDataManager().removeTokens(target.getUniqueId(), amount);
                MessageUtil.send(sender, "token-take", "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{amount}", FormatUtil.formatNum(amount), "{name}", plugin.getConfigManager().getTokenName(), "{player}", target.getName());
            }
            case "reset" -> {
                plugin.getDataManager().setTokens(target.getUniqueId(), 0);
                MessageUtil.send(sender, "token-reset", "{player}", target.getName());
            }
            default -> sender.sendMessage(MessageUtil.toComponent("&cUsage: /stoken <set|add|give|take|reset> <player> <amount>"));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> list = new ArrayList<>();
        if (args.length == 1) list.addAll(List.of("set", "add", "give", "take", "reset"));
        else if (args.length == 2) { for (Player p : Bukkit.getOnlinePlayers()) list.add(p.getName()); }
        return list;
    }
}
