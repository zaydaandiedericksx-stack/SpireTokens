package com.overflaremc.spiretokens.gui;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.data.DataManager;
import com.overflaremc.spiretokens.utils.FormatUtil;
import com.overflaremc.spiretokens.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.entity.Player;

public class ShopGUI implements InventoryHolder {
    private final SpireTokens plugin;
    private final Player player;
    private final Inventory inv;

    public ShopGUI(SpireTokens plugin, Player player) {
        this.plugin = plugin;
        this.player = player;
        int rows = plugin.getShopManager().getRows();
        this.inv = Bukkit.createInventory(this, rows * 9, MessageUtil.toComponent("&6&lToken Shop"));
        build();
    }

    private void build() {
        ItemStack filler = new ItemStack(org.bukkit.Material.valueOf(plugin.getConfigManager().getFillerItem()));
        ItemMeta fm = filler.getItemMeta(); fm.displayName(MessageUtil.toComponent(" ")); filler.setItemMeta(fm);
        for (int i = 0; i < inv.getSize(); i++) inv.setItem(i, filler);
        for (var entry : plugin.getDataManager().getShopItems().entrySet()) {
            int slot = entry.getKey();
            DataManager.ShopItemData data = entry.getValue();
            if (slot < 0 || slot >= inv.getSize()) continue;
            ItemStack display = data.item().clone();
            ItemMeta meta = display.getItemMeta();
            meta.displayName(MessageUtil.toComponent("&e" + display.getType().name()));
            meta.lore(java.util.List.of(MessageUtil.toComponent("&7Price: " + plugin.getConfigManager().getTokenSymbol() + "&6" + FormatUtil.formatNum(data.price())), MessageUtil.toComponent(""), MessageUtil.toComponent("&eClick to select quantity!")));
            display.setItemMeta(meta);
            inv.setItem(slot, display);
        }
    }

    public void open() { player.openInventory(inv); }
    @Override public Inventory getInventory() { return inv; }
}
