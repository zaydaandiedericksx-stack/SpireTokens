package com.overflaremc.spiretokens.gui;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.utils.FormatUtil;
import com.overflaremc.spiretokens.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.entity.Player;

public class QuantityGUI implements InventoryHolder {
    private final SpireTokens plugin;
    private final Player player;
    private final int slot;
    private final ItemStack item;
    private final double price;
    private int qty = 1;
    private final Inventory inv;

    public QuantityGUI(SpireTokens plugin, Player player, int slot, ItemStack item, double price) {
        this.plugin = plugin; this.player = player; this.slot = slot; this.item = item; this.price = price;
        this.inv = Bukkit.createInventory(this, 27, MessageUtil.toComponent("&6&lSelect Quantity"));
        build();
    }

    private void build() {
        ItemStack filler = new ItemStack(Material.BLACK_STAINED_GLASS_PANE);
        ItemMeta fm = filler.getItemMeta(); fm.displayName(MessageUtil.toComponent(" ")); filler.setItemMeta(fm);
        for (int i = 0; i < 27; i++) inv.setItem(i, filler);
        double total = price * qty;
        ItemStack paper = new ItemStack(Material.PAPER);
        ItemMeta pm = paper.getItemMeta();
        pm.displayName(MessageUtil.toComponent("&e&lPrice Info"));
        pm.lore(java.util.List.of(MessageUtil.toComponent("&7Item: &f" + item.getType().name()), MessageUtil.toComponent("&7Each: " + plugin.getConfigManager().getTokenSymbol() + "&6" + FormatUtil.formatNum(price)), MessageUtil.toComponent("&7Qty: &f" + qty), MessageUtil.toComponent("&7Total: " + plugin.getConfigManager().getTokenSymbol() + "&6" + FormatUtil.formatNum(total))));
        paper.setItemMeta(pm); inv.setItem(4, paper);
        ItemStack display = item.clone();
        ItemMeta dm = display.getItemMeta();
        dm.displayName(MessageUtil.toComponent("&e&l" + item.getType().name()));
        dm.lore(java.util.List.of(MessageUtil.toComponent("&7Click to buy!"), MessageUtil.toComponent("&7Qty: &f" + qty)));
        display.setItemMeta(dm); inv.setItem(13, display);
        inv.setItem(10, button(Material.RED_STAINED_GLASS_PANE, "&c-1"));
        inv.setItem(11, button(Material.RED_STAINED_GLASS_PANE, "&c-16"));
        inv.setItem(12, button(Material.RED_STAINED_GLASS_PANE, "&c-32"));
        inv.setItem(14, button(Material.GREEN_STAINED_GLASS_PANE, "&a+1"));
        inv.setItem(15, button(Material.GREEN_STAINED_GLASS_PANE, "&a+32"));
        inv.setItem(16, button(Material.GREEN_STAINED_GLASS_PANE, "&a+64"));
        ItemStack buy = new ItemStack(Material.EMERALD_BLOCK);
        ItemMeta bm = buy.getItemMeta();
        bm.displayName(MessageUtil.toComponent("&a&lBUY NOW"));
        bm.lore(java.util.List.of(MessageUtil.toComponent("&7Click to purchase!")));
        buy.setItemMeta(bm); inv.setItem(22, buy);
    }

    private ItemStack button(Material mat, String name) {
        ItemStack btn = new ItemStack(mat);
        ItemMeta m = btn.getItemMeta(); m.displayName(MessageUtil.toComponent(name)); btn.setItemMeta(m);
        return btn;
    }

    public void update() { build(); player.openInventory(inv); }
    public void open() { player.openInventory(inv); }
    public int getSlot() { return slot; }
    public int getQty() { return qty; }
    public void setQty(int q) { this.qty = Math.max(1, Math.min(64, q)); }
    @Override public Inventory getInventory() { return inv; }
}
