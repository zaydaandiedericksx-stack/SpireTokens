package com.overflaremc.spiretokens.commands;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.utils.FormatUtil;
import com.overflaremc.spiretokens.utils.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class SpireTokensCommand implements CommandExecutor {
    private final SpireTokens plugin;
    public SpireTokensCommand(SpireTokens plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Player only!"); return true;
        }
        if (args.length == 0 || args[0].equalsIgnoreCase("help")) {
            MessageUtil.send(player, "help-header");
            MessageUtil.send(player, "help-tokens");
            MessageUtil.send(player, "help-tokenshop");
            MessageUtil.send(player, "help-rank");
            MessageUtil.send(player, "help-rankup");
            MessageUtil.send(player, "help-tokenmult");
            if (player.hasPermission("spiretokens.admin")) {
                MessageUtil.send(player, "help-stoken");
                MessageUtil.send(player, "help-afk");
                MessageUtil.send(player, "help-setrank");
            }
            MessageUtil.send(player, "help-footer");
            return true;
        }
        // If they type /stoken without help, show balance
        double bal = plugin.getDataManager().getTokens(player.getUniqueId());
        double mult = plugin.getAFKManager().getMultiplier(player);
        player.sendMessage(MessageUtil.toComponent("&6&l========== " + plugin.getConfigManager().getTokenName() + " Balance =========="));
        player.sendMessage(MessageUtil.toComponent("&7Your balance: " + plugin.getConfigManager().getTokenSymbol() + "&e" + FormatUtil.formatNum(bal)));
        if (mult > 1) player.sendMessage(MessageUtil.toComponent("&7Multiplier: &6x" + mult));
        player.sendMessage(MessageUtil.toComponent("&6&l========================================"));
        return true;
    }
}
