package com.overflaremc.spiretokens.commands;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.utils.FormatUtil;
import com.overflaremc.spiretokens.utils.MessageUtil;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class SetRankCommand implements CommandExecutor, TabExecutor {
    private final SpireTokens plugin;
    public SetRankCommand(SpireTokens plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length < 2) { sender.sendMessage(MessageUtil.toComponent("&cUsage: /setrank <player> <tier>")); return true; }
        OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
        if (target == null || (!target.hasPlayedBefore() && !target.isOnline())) { MessageUtil.send(sender, "player-not-found"); return true; }
        int tier = FormatUtil.parseInt(args[1]);
        if (tier < 0) tier = 0; if (tier > 5) tier = 5;
        if (target.isOnline() && target.getPlayer() != null) plugin.getRankManager().setRank(target.getPlayer(), tier);
        else plugin.getDataManager().setRank(target.getUniqueId(), tier);
        MessageUtil.send(sender, "setrank-success", "{player}", target.getName(), "{rank}", plugin.getRankManager().getRankName(tier));
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> list = new ArrayList<>();
        if (args.length == 1) { for (Player p : Bukkit.getOnlinePlayers()) list.add(p.getName()); }
        else if (args.length == 2) list.addAll(List.of("0", "1", "2", "3", "4", "5"));
        return list;
    }
}
