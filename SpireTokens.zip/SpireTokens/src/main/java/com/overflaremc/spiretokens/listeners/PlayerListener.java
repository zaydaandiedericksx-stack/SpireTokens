package com.overflaremc.spiretokens.listeners;

import com.overflaremc.spiretokens.SpireTokens;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerJoinEvent;

public class PlayerListener implements Listener {
    private final SpireTokens plugin;
    public PlayerListener(SpireTokens plugin) { this.plugin = plugin; }

    @EventHandler
    public void onJoin(PlayerJoinEvent event) {
        var dm = plugin.getDataManager();
        if (!dm.getTokenCache().containsKey(event.getPlayer().getUniqueId())) dm.setTokens(event.getPlayer().getUniqueId(), 0);
        if (!dm.getRankCache().containsKey(event.getPlayer().getUniqueId())) dm.setRank(event.getPlayer().getUniqueId(), 0);
    }
}
