package com.overflaremc.spiretokens;

import com.overflaremc.spiretokens.afk.AFKManager;
import com.overflaremc.spiretokens.commands.*;
import com.overflaremc.spiretokens.config.ConfigManager;
import com.overflaremc.spiretokens.data.DataManager;
import com.overflaremc.spiretokens.gui.GUIListener;
import com.overflaremc.spiretokens.listeners.DeathListener;
import com.overflaremc.spiretokens.listeners.PlayerListener;
import com.overflaremc.spiretokens.placeholders.TokenExpansion;
import com.overflaremc.spiretokens.rank.RankManager;
import com.overflaremc.spiretokens.shop.ShopManager;
import net.luckperms.api.LuckPerms;
import net.milkbowl.vault.economy.Economy;
import org.bukkit.Bukkit;
import org.bukkit.plugin.RegisteredServiceProvider;
import org.bukkit.plugin.java.JavaPlugin;

public final class SpireTokens extends JavaPlugin {

    private static SpireTokens instance;
    private ConfigManager configManager;
    private DataManager dataManager;
    private ShopManager shopManager;
    private AFKManager afkManager;
    private RankManager rankManager;
    private LuckPerms luckPerms;
    private Economy vaultEconomy;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        this.configManager = new ConfigManager(this);
        this.dataManager = new DataManager(this);
        this.shopManager = new ShopManager(this);
        this.afkManager = new AFKManager(this);
        this.rankManager = new RankManager(this);

        setupLuckPerms();
        setupVault();

        registerCommands();
        registerListeners();
        registerPlaceholders();

        afkManager.startAFKTask();

        getLogger().info("SpireTokens v" + getDescription().getVersion() + " enabled!");
    }

    @Override
    public void onDisable() {
        if (dataManager != null) dataManager.saveAll();
        if (afkManager != null) afkManager.stopAFKTask();
        getLogger().info("SpireTokens disabled!");
    }

    private void setupLuckPerms() {
        RegisteredServiceProvider<LuckPerms> provider = Bukkit.getServicesManager().getRegistration(LuckPerms.class);
        if (provider != null) {
            luckPerms = provider.getProvider();
        } else {
            getLogger().warning("LuckPerms not found! Rank system will not work.");
        }
    }

    private void setupVault() {
        if (getServer().getPluginManager().getPlugin("Vault") != null) {
            RegisteredServiceProvider<Economy> rsp = getServer().getServicesManager().getRegistration(Economy.class);
            if (rsp != null) {
                vaultEconomy = rsp.getProvider();
            }
        }
    }

    private void registerCommands() {
        getCommand("spiretokens").setExecutor(new SpireTokensCommand(this));
        getCommand("tokenshop").setExecutor(new TokenShopCommand(this));
        getCommand("tokenshop").setTabCompleter(new TokenShopCommand(this));
        getCommand("rank").setExecutor(new RankCommand(this));
        getCommand("rankup").setExecutor(new RankUpCommand(this));
        getCommand("stoken").setExecutor(new TokenAdminCommand(this));
        getCommand("stoken").setTabCompleter(new TokenAdminCommand(this));
        getCommand("afk").setExecutor(new AFKCommand(this));
        getCommand("afk").setTabCompleter(new AFKCommand(this));
        getCommand("setrank").setExecutor(new SetRankCommand(this));
        getCommand("setrank").setTabCompleter(new SetRankCommand(this));
        getCommand("tokenmult").setExecutor(new TokenMultCommand(this));
    }

    private void registerListeners() {
        getServer().getPluginManager().registerEvents(new PlayerListener(this), this);
        getServer().getPluginManager().registerEvents(new DeathListener(this), this);
        getServer().getPluginManager().registerEvents(new GUIListener(this), this);
        getServer().getPluginManager().registerEvents(afkManager, this);
    }

    private void registerPlaceholders() {
        if (Bukkit.getPluginManager().getPlugin("PlaceholderAPI") != null) {
            new TokenExpansion(this).register();
            getLogger().info("PlaceholderAPI found! Placeholders registered.");
        } else {
            getLogger().warning("PlaceholderAPI not found! Placeholders will not work.");
        }
    }

    public static SpireTokens getInstance() { return instance; }
    public ConfigManager getConfigManager() { return configManager; }
    public DataManager getDataManager() { return dataManager; }
    public ShopManager getShopManager() { return shopManager; }
    public AFKManager getAFKManager() { return afkManager; }
    public RankManager getRankManager() { return rankManager; }
    public LuckPerms getLuckPerms() { return luckPerms; }
    public Economy getVaultEconomy() { return vaultEconomy; }
}
