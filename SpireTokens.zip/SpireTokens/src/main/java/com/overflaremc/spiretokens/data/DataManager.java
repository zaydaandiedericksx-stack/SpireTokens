package com.overflaremc.spiretokens.data;

import com.overflaremc.spiretokens.SpireTokens;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.inventory.ItemStack;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;

public class DataManager {
    private final SpireTokens plugin;
    private final File dataFolder;
    private final File playersFile;
    private final File shopFile;
    private final File afkFile;
    private FileConfiguration playersConfig;
    private FileConfiguration shopConfig;
    private FileConfiguration afkConfig;
    private final Map<UUID, Double> tokenCache = new ConcurrentHashMap<>();
    private final Map<UUID, Integer> rankCache = new ConcurrentHashMap<>();
    private final Map<Integer, ShopItemData> shopCache = new ConcurrentHashMap<>();
    private final Map<Integer, AFKAreaData> afkCache = new ConcurrentHashMap<>();
    private int afkAreaCount = 0;

    public DataManager(SpireTokens plugin) {
        this.plugin = plugin;
        this.dataFolder = new File(plugin.getDataFolder(), "data");
        if (!dataFolder.exists()) dataFolder.mkdirs();
        this.playersFile = new File(dataFolder, "players.yml");
        this.shopFile = new File(dataFolder, "shop.yml");
        this.afkFile = new File(dataFolder, "afk.yml");
        loadAll();
    }

    public void loadAll() {
        loadPlayers();
        loadShop();
        loadAFK();
    }

    public void saveAll() {
        savePlayers();
        saveShop();
        saveAFK();
    }

    private void loadPlayers() {
        if (!playersFile.exists()) { playersConfig = new YamlConfiguration(); return; }
        playersConfig = YamlConfiguration.loadConfiguration(playersFile);
        for (String key : playersConfig.getKeys(false)) {
            try {
                UUID uuid = UUID.fromString(key);
                tokenCache.put(uuid, playersConfig.getDouble(key + ".tokens", 0.0));
                rankCache.put(uuid, playersConfig.getInt(key + ".rank", 0));
            } catch (IllegalArgumentException ignored) {}
        }
    }

    public void savePlayers() {
        playersConfig = new YamlConfiguration();
        for (Map.Entry<UUID, Double> entry : tokenCache.entrySet()) {
            String path = entry.getKey().toString();
            playersConfig.set(path + ".tokens", entry.getValue());
            playersConfig.set(path + ".rank", rankCache.getOrDefault(entry.getKey(), 0));
        }
        saveFile(playersConfig, playersFile);
    }

    public double getTokens(UUID uuid) { return tokenCache.getOrDefault(uuid, 0.0); }
    public void setTokens(UUID uuid, double amount) { tokenCache.put(uuid, Math.max(0, amount)); asyncSave(); }
    public void addTokens(UUID uuid, double amount) { setTokens(uuid, getTokens(uuid) + amount); }
    public void removeTokens(UUID uuid, double amount) { setTokens(uuid, getTokens(uuid) - amount); }
    public int getRank(UUID uuid) { return rankCache.getOrDefault(uuid, 0); }
    public void setRank(UUID uuid, int tier) { rankCache.put(uuid, Math.max(0, Math.min(5, tier))); asyncSave(); }
    public Map<UUID, Double> getTokenCache() { return tokenCache; }
    public Map<UUID, Integer> getRankCache() { return rankCache; }

    private void loadShop() {
        if (!shopFile.exists()) { shopConfig = new YamlConfiguration(); return; }
        shopConfig = YamlConfiguration.loadConfiguration(shopFile);
        if (shopConfig.contains("size")) plugin.getShopManager().setRows(shopConfig.getInt("size", 3));
        if (shopConfig.contains("items")) {
            for (String key : shopConfig.getConfigurationSection("items").getKeys(false)) {
                try {
                    int slot = Integer.parseInt(key);
                    ItemStack item = shopConfig.getItemStack("items." + key);
                    double price = shopConfig.getDouble("prices." + key, plugin.getConfigManager().getDefaultShopPrice());
                    if (item != null) shopCache.put(slot, new ShopItemData(item, price));
                } catch (NumberFormatException ignored) {}
            }
        }
    }

    public void saveShop() {
        shopConfig = new YamlConfiguration();
        shopConfig.set("size", plugin.getShopManager().getRows());
        for (Map.Entry<Integer, ShopItemData> entry : shopCache.entrySet()) {
            String path = String.valueOf(entry.getKey());
            shopConfig.set("items." + path, entry.getValue().item());
            shopConfig.set("prices." + path, entry.getValue().price());
        }
        saveFile(shopConfig, shopFile);
    }

    public ShopItemData getShopItem(int slot) { return shopCache.get(slot); }
    public void setShopItem(int slot, ItemStack item, double price) { shopCache.put(slot, new ShopItemData(item.clone(), price)); }
    public void removeShopItem(int slot) { shopCache.remove(slot); }
    public Map<Integer, ShopItemData> getShopItems() { return new HashMap<>(shopCache); }
    public void setShopPrice(int slot, double price) {
        ShopItemData data = shopCache.get(slot);
        if (data != null) shopCache.put(slot, new ShopItemData(data.item(), price));
    }

    private void loadAFK() {
        if (!afkFile.exists()) { afkConfig = new YamlConfiguration(); return; }
        afkConfig = YamlConfiguration.loadConfiguration(afkFile);
        afkAreaCount = afkConfig.getInt("count", 0);
        if (afkConfig.contains("areas")) {
            for (String key : afkConfig.getConfigurationSection("areas").getKeys(false)) {
                try {
                    int id = Integer.parseInt(key);
                    Location pos1 = deserializeLocation(afkConfig.getString("areas." + key + ".pos1"));
                    Location pos2 = deserializeLocation(afkConfig.getString("areas." + key + ".pos2"));
                    if (pos1 != null && pos2 != null) afkCache.put(id, new AFKAreaData(pos1, pos2));
                } catch (NumberFormatException ignored) {}
            }
        }
    }

    public void saveAFK() {
        afkConfig = new YamlConfiguration();
        afkConfig.set("count", afkAreaCount);
        for (Map.Entry<Integer, AFKAreaData> entry : afkCache.entrySet()) {
            String path = "areas." + entry.getKey();
            afkConfig.set(path + ".pos1", serializeLocation(entry.getValue().pos1()));
            afkConfig.set(path + ".pos2", serializeLocation(entry.getValue().pos2()));
        }
        saveFile(afkConfig, afkFile);
    }

    public int addAFKArea(Location pos1, Location pos2) {
        afkAreaCount++;
        afkCache.put(afkAreaCount, new AFKAreaData(pos1, pos2));
        saveAFK();
        return afkAreaCount;
    }
    public void removeAFKArea(int id) { afkCache.remove(id); saveAFK(); }
    public AFKAreaData getAFKArea(int id) { return afkCache.get(id); }
    public Map<Integer, AFKAreaData> getAFKAreas() { return new HashMap<>(afkCache); }
    public int getAFKAreaCount() { return afkAreaCount; }

    private void saveFile(FileConfiguration config, File file) {
        try { config.save(file); }
        catch (IOException e) { plugin.getLogger().severe("Could not save " + file.getName() + ": " + e.getMessage()); }
    }
    private void asyncSave() { Bukkit.getScheduler().runTaskAsynchronously(plugin, this::savePlayers); }
    private String serializeLocation(Location loc) { return loc.getWorld().getName() + ";" + loc.getX() + ";" + loc.getY() + ";" + loc.getZ(); }
    private Location deserializeLocation(String str) {
        if (str == null) return null;
        String[] parts = str.split(";");
        if (parts.length != 4) return null;
        World world = Bukkit.getWorld(parts[0]);
        if (world == null) return null;
        try { return new Location(world, Double.parseDouble(parts[1]), Double.parseDouble(parts[2]), Double.parseDouble(parts[3])); }
        catch (NumberFormatException e) { return null; }
    }

    public record ShopItemData(ItemStack item, double price) {}
    public record AFKAreaData(Location pos1, Location pos2) {}
}
