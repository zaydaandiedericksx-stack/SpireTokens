package com.overflaremc.spiretokens.config;

import com.overflaremc.spiretokens.SpireTokens;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.FileConfiguration;

public class ConfigManager {
    private final SpireTokens plugin;
    private final FileConfiguration config;

    public ConfigManager(SpireTokens plugin) {
        this.plugin = plugin;
        this.config = plugin.getConfig();
    }

    public String getTokenSymbol() { return color(config.getString("tokens.symbol", "&6₽")); }
    public String getTokenName() { return color(config.getString("tokens.name", "&eToken")); }
    public int getKillReward() { return config.getInt("tokens.kill-reward", 50); }
    public int getAFKReward() { return config.getInt("tokens.afk-reward", 10); }
    public int getAFKInterval() { return config.getInt("tokens.afk-interval", 60); }
    public int getDefaultShopRows() { return config.getInt("shop.default-rows", 3); }
    public int getDefaultShopPrice() { return config.getInt("shop.default-price", 100); }
    public String getFillerItem() { return config.getString("shop.filler-item", "BLACK_STAINED_GLASS_PANE"); }

    public String getMessage(String key) {
        return color(config.getString("messages." + key, "&cMessage not found: " + key));
    }
    public String getMessage(String key, String... replacements) {
        String msg = getMessage(key);
        for (int i = 0; i < replacements.length; i += 2) {
            if (i + 1 < replacements.length) msg = msg.replace(replacements[i], replacements[i + 1]);
        }
        return msg;
    }
    public Component getComponent(String key) { return toComponent(getMessage(key)); }
    public Component getComponent(String key, String... replacements) { return toComponent(getMessage(key, replacements)); }
    public ConfigurationSection getRanksSection() { return config.getConfigurationSection("ranks"); }
    public ConfigurationSection getMultipliersSection() { return config.getConfigurationSection("multipliers"); }
    public double getMultiplier(String permission) {
        ConfigurationSection section = getMultipliersSection();
        if (section == null) return 1.0;
        return section.getDouble(permission, 1.0);
    }

    public static String color(String text) { return text == null ? "" : text; }
    public static Component toComponent(String text) { return LegacyComponentSerializer.legacyAmpersand().deserialize(text); }
}
