package com.overflaremc.spiretokens.placeholders;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.utils.FormatUtil;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

public class TokenExpansion extends PlaceholderExpansion {
    private final SpireTokens plugin;

    public TokenExpansion(SpireTokens plugin) { this.plugin = plugin; }

    @Override
    public @NotNull String getIdentifier() { return "spiretokens"; }

    @Override
    public @NotNull String getAuthor() { return "OverFlareMC"; }

    @Override
    public @NotNull String getVersion() { return plugin.getDescription().getVersion(); }

    @Override
    public boolean persist() { return true; }

    @Override
    public boolean canRegister() { return true; }

    @Override
    public @Nullable String onPlaceholderRequest(Player player, @NotNull String params) {
        if (player == null) return "0";
        if (params.isEmpty() || params.equalsIgnoreCase("tokens") || params.equalsIgnoreCase("balance")) {
            return FormatUtil.formatNum(plugin.getDataManager().getTokens(player.getUniqueId()));
        }
        if (params.equalsIgnoreCase("vaultmoney") || params.equalsIgnoreCase("money")) {
            if (plugin.getVaultEconomy() != null) return FormatUtil.formatNum(plugin.getVaultEconomy().getBalance(player));
            return "0";
        }
        if (params.equalsIgnoreCase("rank")) {
            return plugin.getRankManager().getRankName(plugin.getDataManager().getRank(player.getUniqueId()));
        }
        if (params.equalsIgnoreCase("multiplier") || params.equalsIgnoreCase("mult")) {
            return String.valueOf(plugin.getAFKManager().getMultiplier(player));
        }
        return null;
    }
}
