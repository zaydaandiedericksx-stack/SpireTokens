package com.overflaremc.spiretokens.utils;

import java.text.DecimalFormat;

public class FormatUtil {
    private static final DecimalFormat DF = new DecimalFormat("#,##0.0");
    private static final DecimalFormat WHOLE = new DecimalFormat("#,##0");

    public static String formatNum(double number) {
        if (number >= 1_000_000_000_000_000d) return DF.format(number / 1_000_000_000_000_000d) + "q";
        if (number >= 1_000_000_000d) return DF.format(number / 1_000_000_000d) + "b";
        if (number >= 1_000_000d) return DF.format(number / 1_000_000d) + "m";
        if (number >= 1_000d) return DF.format(number / 1_000d) + "k";
        if (number == (long) number) return WHOLE.format(number);
        return DF.format(number);
    }
    public static String formatTokens(double amount) { return formatNum(amount); }
    public static int parseInt(String input) { try { return Integer.parseInt(input); } catch (NumberFormatException e) { return -1; } }
    public static double parseDouble(String input) { try { return Double.parseDouble(input); } catch (NumberFormatException e) { return -1; } }
}
