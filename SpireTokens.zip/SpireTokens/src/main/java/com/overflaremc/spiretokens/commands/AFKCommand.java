package com.overflaremc.spiretokens.commands;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.data.DataManager;
import com.overflaremc.spiretokens.utils.FormatUtil;
import com.overflaremc.spiretokens.utils.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabExecutor;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class AFKCommand implements CommandExecutor, TabExecutor {
    private final SpireTokens plugin;
    public AFKCommand(SpireTokens plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Player only!"); return true; }
        if (args.length == 0) { player.sendMessage(MessageUtil.toComponent("&cUsage: /afk <wand|set|delete|list>")); return true; }
        switch (args[0].toLowerCase()) {
            case "wand" -> plugin.getAFKManager().giveWand(player);
            case "set" -> {
                if (!plugin.getAFKManager().canCreateArea(player)) return true;
                int id = plugin.getAFKManager().createArea(player);
                DataManager.AFKAreaData area = plugin.getDataManager().getAFKArea(id);
                player.sendMessage(MessageUtil.toComponent(plugin.getConfigManager().getMessage("afk-created", "{id}", String.valueOf(id))));
                player.sendMessage(MessageUtil.toComponent("&7From: &e" + area.pos1().getBlockX() + ", " + area.pos1().getBlockY() + ", " + area.pos1().getBlockZ() + " &7To: &e" + area.pos2().getBlockX() + ", " + area.pos2().getBlockY() + ", " + area.pos2().getBlockZ()));
            }
            case "delete" -> {
                if (args.length < 2) { player.sendMessage(MessageUtil.toComponent("&cUsage: /afk delete <id>")); return true; }
                int id = FormatUtil.parseInt(args[1]);
                if (plugin.getDataManager().getAFKArea(id) == null) { player.sendMessage(MessageUtil.toComponent(plugin.getConfigManager().getMessage("afk-not-found", "{id}", String.valueOf(id)))); return true; }
                plugin.getAFKManager().deleteArea(id);
                MessageUtil.send(player, "afk-deleted", "{id}", String.valueOf(id));
            }
            case "list" -> {
                player.sendMessage(MessageUtil.toComponent("&6&lAFK Areas:"));
                boolean found = false;
                for (var entry : plugin.getDataManager().getAFKAreas().entrySet()) {
                    player.sendMessage(MessageUtil.toComponent("&7Area &e#" + entry.getKey() + " &7- &aActive"));
                    found = true;
                }
                if (!found) player.sendMessage(MessageUtil.toComponent("&7No AFK areas set."));
            }
            default -> player.sendMessage(MessageUtil.toComponent("&cUnknown subcommand."));
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> list = new ArrayList<>();
        if (args.length == 1) list.addAll(List.of("wand", "set", "delete", "list"));
        return list;
    }
}
