package com.overflaremc.spiretokens.commands;

import com.overflaremc.spiretokens.SpireTokens;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class RankUpCommand implements CommandExecutor {
    private final SpireTokens plugin;
    public RankUpCommand(SpireTokens plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Player only!"); return true; }
        plugin.getRankManager().rankUp(player);
        return true;
    }
}
