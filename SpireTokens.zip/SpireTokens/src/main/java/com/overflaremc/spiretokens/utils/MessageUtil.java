package com.overflaremc.spiretokens.utils;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.config.ConfigManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class MessageUtil {
    private static ConfigManager getConfig() { return SpireTokens.getInstance().getConfigManager(); }
    public static void send(CommandSender sender, String key) { sender.sendMessage(toComponent(getConfig().getMessage(key))); }
    public static void send(CommandSender sender, String key, String... replacements) { sender.sendMessage(toComponent(getConfig().getMessage(key, replacements))); }
    public static void sendRaw(CommandSender sender, String message) { sender.sendMessage(toComponent(message)); }
    public static void sendActionBar(Player player, String message) { player.sendActionBar(toComponent(message)); }
    public static void broadcast(String key, String... replacements) {
        String msg = getConfig().getMessage(key, replacements);
        SpireTokens.getInstance().getServer().broadcast(toComponent(msg));
    }
    public static Component toComponent(String text) { return LegacyComponentSerializer.legacyAmpersand().deserialize(text); }
}
