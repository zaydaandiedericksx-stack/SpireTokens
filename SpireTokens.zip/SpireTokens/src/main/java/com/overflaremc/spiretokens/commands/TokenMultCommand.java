package com.overflaremc.spiretokens.commands;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.utils.MessageUtil;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class TokenMultCommand implements CommandExecutor {
    private final SpireTokens plugin;
    public TokenMultCommand(SpireTokens plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) { sender.sendMessage("Player only!"); return true; }
        double mult = plugin.getAFKManager().getMultiplier(player);
        player.sendMessage(MessageUtil.toComponent("&7Your token multiplier: &6x" + mult));
        return true;
    }
}
