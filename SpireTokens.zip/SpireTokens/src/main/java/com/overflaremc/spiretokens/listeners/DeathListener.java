package com.overflaremc.spiretokens.listeners;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.utils.FormatUtil;
import com.overflaremc.spiretokens.utils.MessageUtil;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.PlayerDeathEvent;

public class DeathListener implements Listener {
    private final SpireTokens plugin;
    public DeathListener(SpireTokens plugin) { this.plugin = plugin; }

    @EventHandler
    public void onDeath(PlayerDeathEvent event) {
        Player victim = event.getPlayer();
        Player killer = victim.getKiller();
        if (killer == null) return;
        double mult = plugin.getAFKManager().getMultiplier(killer);
        double amount = plugin.getConfigManager().getKillReward() * mult;
        plugin.getDataManager().addTokens(killer.getUniqueId(), amount);
        if (mult > 1) killer.sendMessage(MessageUtil.toComponent(plugin.getConfigManager().getMessage("kill-reward-mult", "{amount}", FormatUtil.formatNum(amount), "{name}", plugin.getConfigManager().getTokenName(), "{mult}", String.valueOf(mult))));
        else killer.sendMessage(MessageUtil.toComponent(plugin.getConfigManager().getMessage("kill-reward", "{amount}", FormatUtil.formatNum(amount), "{name}", plugin.getConfigManager().getTokenName())));
    }
}
