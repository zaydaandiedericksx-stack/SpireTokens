package com.overflaremc.spiretokens.rank;

import com.overflaremc.spiretokens.SpireTokens;
import com.overflaremc.spiretokens.utils.FormatUtil;
import com.overflaremc.spiretokens.utils.MessageUtil;
import net.luckperms.api.LuckPerms;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class RankManager {
    private final SpireTokens plugin;
    private final Map<Integer, RankData> ranks = new HashMap<>();

    public RankManager(SpireTokens plugin) {
        this.plugin = plugin;
        loadRanks();
    }

    private void loadRanks() {
        ConfigurationSection section = plugin.getConfigManager().getRanksSection();
        if (section == null) return;
        for (String key : section.getKeys(false)) {
            ConfigurationSection rankSec = section.getConfigurationSection(key);
            if (rankSec == null) continue;
            int tier = rankSec.getInt("tier");
            ranks.put(tier, new RankData(tier, rankSec.getString("name", "None"), rankSec.getString("group", "none"), rankSec.getString("prefix", ""), rankSec.getInt("cost", 0)));
        }
    }

    public RankData getRank(int tier) { return ranks.getOrDefault(tier, new RankData(0, "None", "none", "", 0)); }
    public String getRankName(int tier) { return getRank(tier).name(); }
    public String getRankGroup(int tier) { return getRank(tier).group(); }
    public String getRankPrefix(int tier) { return getRank(tier).prefix(); }
    public int getRankCost(int tier) { return getRank(tier).cost(); }

    public boolean rankUp(Player player) {
        UUID uuid = player.getUniqueId();
        int currentTier = plugin.getDataManager().getRank(uuid);
        if (currentTier >= 5) { MessageUtil.send(player, "rankup-max"); return false; }
        int nextTier = currentTier + 1;
        int cost = getRankCost(nextTier);
        double balance = plugin.getDataManager().getTokens(uuid);
        if (balance < cost) {
            MessageUtil.send(player, "rankup-need", "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{cost}", FormatUtil.formatNum(cost), "{next}", getRankName(nextTier));
            return false;
        }
        plugin.getDataManager().removeTokens(uuid, cost);
        plugin.getDataManager().setRank(uuid, nextTier);
        updateLuckPerms(player, currentTier, nextTier);
        MessageUtil.send(player, "rankup-success", "{rank}", getRankName(nextTier), "{symbol}", plugin.getConfigManager().getTokenSymbol(), "{cost}", FormatUtil.formatNum(cost));
        MessageUtil.broadcast("rankup-broadcast", "{player}", player.getName(), "{rank}", getRankName(nextTier));
        return true;
    }

    public void setRank(Player player, int tier) {
        UUID uuid = player.getUniqueId();
        int oldTier = plugin.getDataManager().getRank(uuid);
        plugin.getDataManager().setRank(uuid, tier);
        updateLuckPerms(player, oldTier, tier);
    }

    private void updateLuckPerms(Player player, int oldTier, int newTier) {
        LuckPerms lp = plugin.getLuckPerms();
        if (lp == null) return;
        String oldGroup = getRankGroup(oldTier);
        String newGroup = getRankGroup(newTier);
        String newPrefix = getRankPrefix(newTier);
        lp.getUserManager().modifyUser(player.getUniqueId(), user -> {
            if (!oldGroup.equals("none")) {
                user.data().remove(node -> node instanceof net.luckperms.api.node.types.InheritanceNode
                    && ((net.luckperms.api.node.types.InheritanceNode) node).getGroupName().equalsIgnoreCase(oldGroup));
            }
            if (!newGroup.equals("none")) {
                user.data().add(net.luckperms.api.node.Node.builder("group." + newGroup).build());
            }
            if (!newPrefix.isEmpty()) {
                user.data().add(net.luckperms.api.node.Node.builder("prefix.100." + newPrefix).build());
            }
        });
    }

    public record RankData(int tier, String name, String group, String prefix, int cost) {}
}
