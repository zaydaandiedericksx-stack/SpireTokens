package com.overflaremc.spiretokens.gui;

import com.overflaremc.spiretokens.SpireTokens;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.InventoryHolder;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class GUIListener implements Listener {
    private final SpireTokens plugin;
    private final Map<UUID, QuantityGUI> quantityGUIs = new HashMap<>();

    public GUIListener(SpireTokens plugin) { this.plugin = plugin; }
    public void registerQuantity(Player player, QuantityGUI gui) { quantityGUIs.put(player.getUniqueId(), gui); }

    @EventHandler
    public void onClick(InventoryClickEvent event) {
        if (!(event.getWhoClicked() instanceof Player player)) return;
        InventoryHolder holder = event.getInventory().getHolder();
        if (holder instanceof ShopGUI) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            if (plugin.getDataManager().getShopItem(slot) != null) {
                QuantityGUI qg = new QuantityGUI(plugin, player, slot, plugin.getDataManager().getShopItem(slot).item(), plugin.getDataManager().getShopItem(slot).price());
                qg.open(); registerQuantity(player, qg);
            }
        } else if (holder instanceof QuantityGUI gui) {
            event.setCancelled(true);
            int slot = event.getRawSlot();
            switch (slot) {
                case 10 -> { gui.setQty(gui.getQty() - 1); gui.update(); }
                case 11 -> { gui.setQty(gui.getQty() - 16); gui.update(); }
                case 12 -> { gui.setQty(gui.getQty() - 32); gui.update(); }
                case 14 -> { gui.setQty(gui.getQty() + 1); gui.update(); }
                case 15 -> { gui.setQty(gui.getQty() + 32); gui.update(); }
                case 16 -> { gui.setQty(gui.getQty() + 64); gui.update(); }
                case 13, 22 -> {
                    plugin.getShopManager().buyItem(player, gui.getSlot(), gui.getQty());
                    player.closeInventory(); quantityGUIs.remove(player.getUniqueId());
                }
            }
            if (slot != 13 && slot != 22) registerQuantity(player, gui);
        } else if (quantityGUIs.containsKey(player.getUniqueId())) {
            if (event.getInventory().getHolder() == null) quantityGUIs.remove(player.getUniqueId());
        }
    }
}
